/*
 * Universit� Pierre et Marie Curie
 *
 * Programme de multiplication de matrices carrees.
 */ 

#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>
#include <sys/time.h>

double my_gettimeofday(){
  struct timeval tmp_time;
  gettimeofday(&tmp_time, NULL);
  return tmp_time.tv_sec + (tmp_time.tv_usec * 1.0e-6L);
}


#define REAL_T float 
#define NB_TIMES 10

/*** Matmul: ***/
/* C += A x B 
 * square matrices of order 'n'
 */
void matmul(int n, REAL_T *A, REAL_T *B, REAL_T *C){
  int i,j,k;
  __m256 vA0,vA1,vA2,vA3,vA4,vA5,vA6,vA7,vB0,vB1,vB2,vB3,vB4,vB5,vB6,vB7,vC;
  for (i=0; i<n; i++){
    for (j=0; j<n; j+=8){

      vC = _mm256_setzero_ps();
      
      for (k=0; k<n; k+=8){
	
	/*
	printf("bloc %d \n",k);
	for (l=0;l<8;l++){
	  printf("indice A : %d , %d\nelem %d\n",i,k+l,i*n+k+l);
	}
	*/
	vA0  = _mm256_set1_ps(A[i*n+k]);
	vA1  = _mm256_set1_ps(A[i*n+k+1]);
	vA2  = _mm256_set1_ps(A[i*n+k+2]);
	vA3  = _mm256_set1_ps(A[i*n+k+3]);
	vA4  = _mm256_set1_ps(A[i*n+k+4]);
	vA5  = _mm256_set1_ps(A[i*n+k+5]);
	vA6  = _mm256_set1_ps(A[i*n+k+6]);
	vA7  = _mm256_set1_ps(A[i*n+k+7]);
	/*
	printf("vB \n");
	for (l=0;l<8;l++){
	  printf(" k = %d\n j = %d\n indice premier elem ligne %d : %d\n",k,j,l,j+(k+l)*n);
	}
	*/
	
	vB0 = _mm256_load_ps(&B[j+k*n]);
	vB1 = _mm256_load_ps(&B[j+(k+1)*n]);
	vB2 = _mm256_load_ps(&B[j+(k+2)*n]);
	vB3 = _mm256_load_ps(&B[j+(k+3)*n]);
	vB4 = _mm256_load_ps(&B[j+(k+4)*n]);
	vB5 = _mm256_load_ps(&B[j+(k+5)*n]);
	vB6 = _mm256_load_ps(&B[j+(k+6)*n]);
	vB7 = _mm256_load_ps(&B[j+(k+7)*n]);

	vC = _mm256_fmadd_ps(vA0,vB0,vC);
	vC = _mm256_fmadd_ps(vA1,vB1,vC);
	vC = _mm256_fmadd_ps(vA2,vB2,vC);
	vC = _mm256_fmadd_ps(vA3,vB3,vC);
	vC = _mm256_fmadd_ps(vA4,vB4,vC);
	vC = _mm256_fmadd_ps(vA5,vB5,vC);
	vC = _mm256_fmadd_ps(vA6,vB6,vC);
	vC = _mm256_fmadd_ps(vA7,vB7,vC);

	
	
	//printf("fin fmadd\n");
	
	
	
      } /* for k */
      /* on a 8 valeurs de C situ�es de (i,j) � (i,j+7) */
      /*
      printf("On store en %d , %d\n",i,j);
      printf("a l'adresse %p\n",&C[i*n+j]);

      _mm256_store_ps(c,vC);
      for (l=0; l<8; l++){
	printf("%f ",c[l]);
      }
      printf("\n");
      */
      //_mm256_storeu_ps(&C[i*n+j],vC);
      _mm256_store_ps(&C[i*n+j],vC);
    } /* for j */
  } /* for i */
}


int main(int argc, char **argv)
{
  int i,j;
  double debut=0.0, fin=0.0;
  REAL_T *A, *B, *C;
  int n=2; /* default value */
  int nb=0;
  /* Read 'n' on command line: */
  if (argc == 2){
    n = atoi(argv[1]);
  }
  posix_memalign((void **)&A, 32*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&B, 32*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&C, 32*8,n*n*sizeof(REAL_T));


  /* Allocate the matrices: */
  /*
  if ((A = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating A.\n");
  }
  if ((B = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating B.\n");
  }
  if ((C = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating C.\n");
  }
  */

  /* Initialize the matrices */
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++){
      *(A+i*n+j) = 1 / ((REAL_T) (i+j+1));
      *(B+i*n+j) = 1.0;
      *(C+i*n+j) = 1.0;
    }

  /* Start timing */
  debut = my_gettimeofday();
  for (nb=0; nb<NB_TIMES; nb++){
    /* Do matrix-product C=A*B+C */
    matmul(n, A, B, C);
    /* End timing */
  }
  fin = my_gettimeofday();

  fprintf( stdout, "For n=%d: total computation time (with gettimeofday()) : %g s\n",
	   n, (fin - debut)/NB_TIMES);
  fprintf( stdout, "For n=%d: performance = %g Gflop/s \n",
	   n, (((double) 2)*n*n*n / ((fin - debut)/NB_TIMES) )/ ((double) 1e9) ); /* 2n^3 flops */
      
  /* Print 2x2 top-left square of C : */
  for(i=0; i<2 ; i++){
    for(j=0; j<2 ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }
  printf("\n");
  /* Print 2x2 bottom-right square of C : */
  for(i=n-2; i<n ; i++){
    for(j=n-2; j<n ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }

  /* Free the matrices: */
  free(A);
  free(B);
  free(C);

  return 0;
}
