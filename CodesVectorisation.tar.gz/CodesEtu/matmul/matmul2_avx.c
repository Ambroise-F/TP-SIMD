/*
 * Universit� Pierre et Marie Curie
 *
 * Programme de multiplication de matrices carrees.
 */ 

#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>
#include <sys/time.h>

double my_gettimeofday(){
  struct timeval tmp_time;
  gettimeofday(&tmp_time, NULL);
  return tmp_time.tv_sec + (tmp_time.tv_usec * 1.0e-6L);
}


#define REAL_T float 
#define NB_TIMES 10

/*** Matmul: ***/
/* C += A x B 
 * square matrices of order 'n'
 */

void printV(__m256 v){
  REAL_T a[8];
  int i;
  
  _mm256_store_ps(a,v);
  printf("[ ");
  for (i=0; i<8; i++){
    printf("%f ,",a[i]);
  }
  printf("]\n");  
}

void matmul(int n, REAL_T *A, REAL_T *B, REAL_T *C){
  int i,j,k,l;
  __m256 vA,vB,vC;
  REAL_T res,b[8] __attribute__((aligned(32))),c[8] __attribute__((aligned(32)));
  for (i=0; i<n; i++){
    for (j=0; j<n; j++){
      /* une case de C � la fois */
      vC = _mm256_setzero_ps();
      res = 0.0;
      
      for (k=0; k<n; k+=8){
	/* cr�ation du vecteur A (ligne) */
	vA  = _mm256_load_ps(&A[i*n+k]);
	/* cr�ation du tableau de b (colonne) */
	b[0] = B[k*n+j];
	b[1] = B[(k+1)*n+j];
	b[2] = B[(k+2)*n+j];
	b[3] = B[(k+3)*n+j];
	b[4] = B[(k+4)*n+j];
	b[5] = B[(k+5)*n+j];
	b[6] = B[(k+6)*n+j];
	b[7] = B[(k+7)*n+j];
	
	vB  = _mm256_load_ps(b);

	vC = _mm256_fmadd_ps(vA,vB,vC);
      } /* for k */
      /* on calcule la somme des 8 composantes du vecteur vC */
      _mm256_store_ps(c,vC);
      
      for (l=0; l<8; l++){
	res += c[l];
      }
      /* on place le resultat dans C */
      C[i*n+j]=res;
    } /* for j */
  } /* for i */
}


int main(int argc, char **argv)
{
  int i,j;
  double debut=0.0, fin=0.0;
  REAL_T *A, *B, *C;
  int n=2; /* default value */
  int nb=0;
  /* Read 'n' on command line: */
  if (argc == 2){
    n = atoi(argv[1]);
  }
  posix_memalign((void **)&A, 32*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&B, 32*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&C, 32*8,n*n*sizeof(REAL_T));


  /* Allocate the matrices: */
  /*
  if ((A = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating A.\n");
  }
  if ((B = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating B.\n");
  }
  if ((C = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating C.\n");
  }
  */


  /* Initialize the matrices */
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++){
      *(A+i*n+j) = 1 / ((REAL_T) (i+j+1));
      *(B+i*n+j) = 1.0;
      *(C+i*n+j) = 1.0;
    }

  /* Start timing */
  debut = my_gettimeofday();
  for (nb=0; nb<NB_TIMES; nb++){
    /* Do matrix-product C=A*B+C */
    matmul(n, A, B, C);
    /* End timing */
  }
  fin = my_gettimeofday();

  fprintf( stdout, "For n=%d: total computation time (with gettimeofday()) : %g s\n",
	   n, (fin - debut)/NB_TIMES);
  fprintf( stdout, "For n=%d: performance = %g Gflop/s \n",
	   n, (((double) 2)*n*n*n / ((fin - debut)/NB_TIMES) )/ ((double) 1e9) ); /* 2n^3 flops */
      
  /* Print 2x2 top-left square of C : */
  for(i=0; i<2 ; i++){
    for(j=0; j<2 ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }
  printf("\n");
  /* Print 2x2 bottom-right square of C : */
  for(i=n-2; i<n ; i++){
    for(j=n-2; j<n ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }

  /* Free the matrices: */
  free(A);
  free(B);
  free(C);

  return 0;
}
