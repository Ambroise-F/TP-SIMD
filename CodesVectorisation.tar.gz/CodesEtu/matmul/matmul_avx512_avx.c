/*
 * Universit� Pierre et Marie Curie
 *
 * Programme de multiplication de matrices carrees.
 */ 

#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>
#include <zmmintrin.h>
#include <sys/time.h>

double my_gettimeofday(){
  struct timeval tmp_time;
  gettimeofday(&tmp_time, NULL);
  return tmp_time.tv_sec + (tmp_time.tv_usec * 1.0e-6L);
}


#define REAL_T float 
#define NB_TIMES 10

/*** Matmul: ***/
/* C += A x B 
 * square matrices of order 'n'
 */
void matmul(int n, REAL_T *A, REAL_T *B, REAL_T *C){
  int i,j,k;
  __m512 vA0,vA1,vA2,vA3,vA4,vA5,vA6,vA7,vA8,vA9,vA10,vA11,vA12,vA13,vA14,vA15,vB0,vB1,vB2,vB3,vB4,vB5,vB6,vB7,vB8,vB9,vB10,vB11,vB12,vB13,vB14,vB15,vC;
  for (i=0; i<n; i++){
    for (j=0; j<n; j+=16){

      vC = _mm512_setzero_ps();
      
      for (k=0; k<n; k+=16){
	
	vA0  = _mm512_set1_ps(A[i*n+k]);
	vA1  = _mm512_set1_ps(A[i*n+k+1]);
	vA2  = _mm512_set1_ps(A[i*n+k+2]);
	vA3  = _mm512_set1_ps(A[i*n+k+3]);
	vA4  = _mm512_set1_ps(A[i*n+k+4]);
	vA5  = _mm512_set1_ps(A[i*n+k+5]);
	vA6  = _mm512_set1_ps(A[i*n+k+6]);
	vA7  = _mm512_set1_ps(A[i*n+k+7]);
	vA8  = _mm512_set1_ps(A[i*n+k+8]);
	vA9  = _mm512_set1_ps(A[i*n+k+9]);
	vA10  = _mm512_set1_ps(A[i*n+k+10]);
	vA11  = _mm512_set1_ps(A[i*n+k+11]);
	vA12  = _mm512_set1_ps(A[i*n+k+12]);
	vA13  = _mm512_set1_ps(A[i*n+k+13]);
	vA14  = _mm512_set1_ps(A[i*n+k+14]);
	vA15  = _mm512_set1_ps(A[i*n+k+15]);
	
	
	vB0 = _mm512_load_ps(&B[j+k*n]);
	vB1 = _mm512_load_ps(&B[j+(k+1)*n]);
	vB2 = _mm512_load_ps(&B[j+(k+2)*n]);
	vB3 = _mm512_load_ps(&B[j+(k+3)*n]);
	vB4 = _mm512_load_ps(&B[j+(k+4)*n]);
	vB5 = _mm512_load_ps(&B[j+(k+5)*n]);
	vB6 = _mm512_load_ps(&B[j+(k+6)*n]);
	vB7 = _mm512_load_ps(&B[j+(k+7)*n]);
	vB8 = _mm512_load_ps(&B[j+(k+8)*n]);
	vB9 = _mm512_load_ps(&B[j+(k+9)*n]);
	vB10 = _mm512_load_ps(&B[j+(k+10)*n]);
	vB11 = _mm512_load_ps(&B[j+(k+11)*n]);
	vB12 = _mm512_load_ps(&B[j+(k+12)*n]);
	vB13 = _mm512_load_ps(&B[j+(k+13)*n]);
	vB14 = _mm512_load_ps(&B[j+(k+14)*n]);
	vB15 = _mm512_load_ps(&B[j+(k+15)*n]);
	
	vC = _mm512_fmadd_ps(vA0,vB0,vC);
	vC = _mm512_fmadd_ps(vA1,vB1,vC);
	vC = _mm512_fmadd_ps(vA2,vB2,vC);
	vC = _mm512_fmadd_ps(vA3,vB3,vC);
	vC = _mm512_fmadd_ps(vA4,vB4,vC);
	vC = _mm512_fmadd_ps(vA5,vB5,vC);
	vC = _mm512_fmadd_ps(vA6,vB6,vC);
	vC = _mm512_fmadd_ps(vA7,vB7,vC);
	vC = _mm512_fmadd_ps(vA8,vB8,vC);
	vC = _mm512_fmadd_ps(vA9,vB9,vC);
	vC = _mm512_fmadd_ps(vA10,vB10,vC);
	vC = _mm512_fmadd_ps(vA11,vB11,vC);
	vC = _mm512_fmadd_ps(vA12,vB12,vC);
	vC = _mm512_fmadd_ps(vA13,vB13,vC);
	vC = _mm512_fmadd_ps(vA14,vB14,vC);
	vC = _mm512_fmadd_ps(vA15,vB15,vC);
	

	
	
	//printf("fin fmadd\n");
	
	
	
      } /* for k */
      /* on a 16 valeurs de C situ�es de (i,j) � (i,j+15) */
      /*
      printf("On store en %d , %d\n",i,j);
      printf("a l'adresse %p\n",&C[i*n+j]);

      _mm512_store_ps(c,vC);
      for (l=0; l<8; l++){
	printf("%f ",c[l]);
      }
      printf("\n");
      */
      //_mm512_storeu_ps(&C[i*n+j],vC);
      _mm512_store_ps(&C[i*n+j],vC);
    } /* for j */
  } /* for i */
}


int main(int argc, char **argv)
{
  int i,j;
  double debut=0.0, fin=0.0;
  REAL_T *A, *B, *C;
  int n=2; /* default value */
  int nb=0;
  /* Read 'n' on command line: */
  if (argc == 2){
    n = atoi(argv[1]);
  }
  posix_memalign((void **)&A, 64*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&B, 64*8,n*n*sizeof(REAL_T));
  posix_memalign((void **)&C, 64*8,n*n*sizeof(REAL_T));


  /* Allocate the matrices: */
  /*
  if ((A = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating A.\n");
  }
  if ((B = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating B.\n");
  }
  if ((C = (REAL_T *) malloc(n*n*sizeof(REAL_T))) == NULL){
    fprintf(stderr, "Error while allocating C.\n");
  }
  */

  /* Initialize the matrices */
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++){
      *(A+i*n+j) = 1 / ((REAL_T) (i+j+1));
      *(B+i*n+j) = 1.0;
      *(C+i*n+j) = 1.0;
    }

  /* Start timing */
  debut = my_gettimeofday();
  for (nb=0; nb<NB_TIMES; nb++){
    /* Do matrix-product C=A*B+C */
    matmul(n, A, B, C);
    /* End timing */
  }
  fin = my_gettimeofday();

  fprintf( stdout, "For n=%d: total computation time (with gettimeofday()) : %g s\n",
	   n, (fin - debut)/NB_TIMES);
  fprintf( stdout, "For n=%d: performance = %g Gflop/s \n",
	   n, (((double) 2)*n*n*n / ((fin - debut)/NB_TIMES) )/ ((double) 1e9) ); /* 2n^3 flops */
      
  /* Print 2x2 top-left square of C : */
  for(i=0; i<2 ; i++){
    for(j=0; j<2 ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }
  printf("\n");
  /* Print 2x2 bottom-right square of C : */
  for(i=n-2; i<n ; i++){
    for(j=n-2; j<n ; j++)
      printf("%+e  ", C[i*n+j]);
    printf("\n");
  }

  /* Free the matrices: */
  free(A);
  free(B);
  free(C);

  return 0;
}
