#include <sys/time.h>
#include <stdio.h>
#include <immintrin.h>
#include <zmmintrin.h>
//#define N 1024
#define N 16384
//#define N 1048576
//#define N 16777216
//#define NB_TIMES 1
#define NB_TIMES 1000000

double my_gettimeofday(){
  struct timeval tmp_time;
  gettimeofday(&tmp_time, NULL);
  return tmp_time.tv_sec + (tmp_time.tv_usec * 1.0e-6L);
}

float A[N]__attribute__((aligned(64)));
float B[N]__attribute__((aligned(64)));

int main(){
  int i,j,k;
  double start, stop;
  __m512 va,vb,vres;
  float res = 0.0,ares[16] __attribute__((aligned(64)));
  for (i=0;i<N;i++){
    A[i]=1.0;
    B[i]=1.0;
  }

  start = my_gettimeofday();
  
  for (k=0; k<NB_TIMES;k++){

    res = 0;
    for (i=0; i<16; i++){
      ares[i]=0;
    }
    vres = _mm512_load_ps(ares); /* composants de vres à 0 */
    
    
    for (i=0;i<N/16;i++){
      
      va = _mm512_load_ps(&(A[i*16]));
      vb = _mm512_load_ps(&(A[i*16]));
      
      vres = _mm512_fmadd_ps(va,vb,vres); /* vres = vres + va * vb */
      //res += A[i]*B[i]; 
    }
    res = _mm512_reduce_add_ps(vres);
      
  }
    
  stop = my_gettimeofday(); 
  fprintf(stdout, "res = %f \n", res); 
  fprintf(stdout, "Temps total de calcul : %g sec\n", stop - start);

  return 0; 
}

